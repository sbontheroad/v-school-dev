export function genName(names) {
  return {
    type: "GEN_NAME",
    name: name
  }
}
