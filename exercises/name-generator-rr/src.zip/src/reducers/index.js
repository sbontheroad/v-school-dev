let defaultState = {
  names: [],
  randomName: ""
}

const mainReducer = (state = defaultState, action) => {
  if(action.type === "GEN_NAME") {
    return {
      ...state,
      // onClick(event) {
      //   let randomName = (names) => {
      //     let num = arr.length;
      //     num = Math.floor(Math.random() * num);
      //     return names[num];
      //   }
      // }
      name: action.name
    }
  } else {
    return {
      ...state
    }
  }
}

export default mainReducer;
