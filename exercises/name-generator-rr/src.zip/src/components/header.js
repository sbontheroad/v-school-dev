import React from "react";

class Header extends React.Component {
  render() {
    return (
      <div className="jumbotron header">
        <div className="row">
          <h1>Random Name Generator</h1>
        </div>
      </div>
    )
  }
}

export default Header;
