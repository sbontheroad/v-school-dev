import React from "react";

class Footer extends React.Component {
  render() {
    return (
      <div className="footer">
        <h3><a href="https://github.com/sbontheroad">sbontheroad  <i className="fa fa-github" aria-hidden="true"></i></a></h3>
      </div>
    )
  }
}

export default Footer;
