import React from "react";
import ReactDOM from "react-dom";

import "./index.css";
import NavCatch from "./navCatch";

class App extends React.Component {
  render() {
    let navBrand = [
      {
        name: "Catch Phrase",
        url: "#"
      }
    ];
    let navLinks = [
      {
        text: "Strong Bad",
        link: "#"
      },
      {
        text: "Strong Sad",
        link: "#"
      },
      {
        text: "Trogdor",
        link: "#"
      }
    ];
    return (
      <div>
        <NavCatch brand={navBrand} links={navLinks}/>
      </div>
    )
  }
}


ReactDOM.render(<App />, document.querySelector("#root"));
