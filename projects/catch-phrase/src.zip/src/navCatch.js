import React from "react";
import {Nav, Navbar, NavItem} from "react-bootstrap";

class NavCatch extends React.Component {
  render() {
    let links = this.props.links.map((item) => {
      return <NavItem href={item.link}>{item.text}</NavItem>
    });
    let brand = this.props.navBrand.map((item) => {
      return <Navbar.Brand href={item.link}>{item.text}</Navbar.Brand>
    });
    return (
      <Navbar>
        <Navbar.Header>
          <Navbar.Toggle />
          <Navbar>{brand}</Navbar>
        </Navbar.Header>

        <Navbar.Collapse>
          <Nav pullRight>
            {links}
          </Nav>
        </Navbar.Collapse>
      </Navbar>
    )
  }
}

export default NavCatch;
